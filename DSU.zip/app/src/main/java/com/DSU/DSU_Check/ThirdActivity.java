package com.DSU.DSU_Check;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.WindowManager;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ThirdActivity extends AppCompatActivity {
    TextView tv;
    long mNow;

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd k:mm:ss");
    Date mDate = new Date(mNow);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.third);
        tv = (TextView)findViewById(R.id.tv1);
        tv.setText(getTime() + " 발열체크 완료 ");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);

    }
    private String getTime(){
        long mNow = System.currentTimeMillis();
        Date mDate = new Date(mNow);
        return sdf.format(mDate);
    }
}